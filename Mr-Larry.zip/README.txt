Mr. Larry The Fish

Controls:
	WASD or Arrow Keys for moving the character;
	O Key to increase the power level; 
	P Key to pause;

Description:
	The aim of the game is to eat as many fish as possible before time runs out. 
	You can only eat a fish if it matches your power level. 
	The fish are color coded to match the power bar on the right.

Team Members:
	Kirstin Burns: Team Lead & Developer
	Lindsey Kuzich: Developer & Artist
	Jacob Yankee: Developer
	Dominic Boggio: Developer
	Grace Chandler: Artist